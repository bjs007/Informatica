package com.example.bijay.informatica

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.preference.PreferenceManager
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

import org.json.JSONException
import org.json.JSONObject
import java.util.Locale

class MainActivity : AppCompatActivity() {
    //Variable declaration starts here

       //Form fields
    internal var firstName: TextView? = null
    internal var lastName: TextView? = null
    internal var street: TextView? = null
    internal var state: TextView? = null
    internal var city: TextView? = null
    internal var zip: TextView? = null
    internal var submit: Button? = null;

      // Other variables
    internal var geocoder: Geocoder? = null
    internal var latitude: Double? = null
    internal var longitude: Double? = null
    internal var boolean_permission: Boolean = false
    internal var mPref: SharedPreferences? = null
    internal var medit: SharedPreferences.Editor? = null
    // variable declaration ends here

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //getInpuFields assign form variables to respective input
        getInputFieldsAssigned()
        geocoder = getGeocoderInstance()


        (submit as Button).setOnClickListener (object: View.OnClickListener {
            override fun onClick(view: View): Unit {
                if (checkValidation()){
                    submitForm(getJSonObject());
                }
            }
        })

        fn_permission()
    }

    // Assign form fields to respective variables.
    private fun getInputFieldsAssigned(){
        submit = findViewById<View>(R.id.contact_form_button) as Button
        firstName = findViewById<View>(R.id.contact_form_firstName) as TextView
        lastName = findViewById<View>(R.id.contact_form_lastName) as TextView
        street = findViewById<View>(R.id.contact_form_street) as TextView
        state = findViewById<View>(R.id.contact_form_state) as TextView
        city = findViewById<View>(R.id.contact_form_city) as TextView
        zip = findViewById<View>(R.id.contact_form_zip) as TextView
    }

// Function to get Geocode instance
    private fun getGeocoderInstance(): Geocoder{
        return Geocoder(this, Locale.getDefault())
    }

// Function to populate Json Object to send
    private  fun getJSonObject(): JSONObject{
        var fName = (findViewById<View>(R.id.contact_form_firstName) as TextView).text
        var lName = (findViewById<View>(R.id.contact_form_lastName) as TextView).text
        var street = (findViewById<View>(R.id.contact_form_street) as TextView).text
        var city = (findViewById<View>(R.id.contact_form_city) as TextView).text
        var state = (findViewById<View>(R.id.contact_form_state) as TextView).text
        var zip = (findViewById<View>(R.id.contact_form_zip) as TextView).text

        val info = JSONObject()
        try {

            info.put("firstName", fName)
            info.put("lastName", lName)
            info.put("street", street)
            info.put("city", city)
            info.put("state", state)
            info.put("zip", zip)
        } catch (e: JSONException) {
            e.printStackTrace()
        }
        return info;
    }

//Function to send JSON Object to a web service
    private fun submitForm(info: JSONObject) {
        // Submit your form here. your form is valid
        Toast.makeText(this, "Submitting form...", Toast.LENGTH_LONG).show()
    }

// Function to validate form
    private fun checkValidation(): Boolean {
        var ret = true
        if (!Validation.hasTextFirstName((firstName as EditText?)!!)) ret = false
        if (!Validation.hasTextLastName((lastName as EditText?)!!)) ret = false
                return ret
    }

    // Function to check permssion to access location
    private fun fn_permission() {
        if (ContextCompat.checkSelfPermission(applicationContext, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(this@MainActivity, android.Manifest.permission.ACCESS_FINE_LOCATION)) {
            } else {
                ActivityCompat.requestPermissions(this@MainActivity, arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION),
                        REQUEST_PERMISSIONS)
            }
        } else {
            boolean_permission = true
        }
    }

    // Function to request permssion to access location
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        when (requestCode) {
            REQUEST_PERMISSIONS -> {
                if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    boolean_permission = true

                } else {
                    Toast.makeText(applicationContext, "Please allow the permission", Toast.LENGTH_LONG).show()

                }
            }
        }
    }

    // Function to get the address from latitude and longitude
        private val broadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {

            latitude = java.lang.Double.valueOf(intent.getStringExtra("latutide"))
            longitude = java.lang.Double.valueOf(intent.getStringExtra("longitude"))

            var addresses: List<Address>? = null

            try {
                addresses = geocoder!!.getFromLocation(latitude!!, longitude!!, 1)
                val streetFromForm = addresses!![0].thoroughfare
                val cityFromForm = addresses[0].locality
                val stateFromForm = addresses[0].adminArea
                val postalCodeFromForm = addresses[0].postalCode

                street?.text = streetFromForm
                state?.text = stateFromForm
                city?.text = cityFromForm
                zip?.text = postalCodeFromForm
            } catch (e1: Exception) {
                Toast.makeText(applicationContext, "Unable to retrieve street/state/City/zip", Toast.LENGTH_LONG).show()
                e1.printStackTrace()
            }

        }
    }
    override fun onStart(){
        super.onStart()

        mPref = PreferenceManager.getDefaultSharedPreferences(applicationContext)
        medit = mPref?.edit()


        val intent = Intent(applicationContext, GoogleService::class.java)
        startService(intent)

    }
    override fun onResume() {
        super.onResume()
        registerReceiver(broadcastReceiver, IntentFilter(GoogleService.str_receiver))

    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(broadcastReceiver)
    }

    companion object {
        private val REQUEST_PERMISSIONS = 100
    }

}
