package com.example.bijay.informatica

/**
 * Created by Bijay on 9/28/2017.
 */


import android.annotation.SuppressLint
import android.app.Service
import android.content.Context
import android.content.Intent
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.util.Log

import java.util.Timer
import java.util.TimerTask


class GoogleService : Service(), LocationListener {

    internal var isGPSEnable = false
    internal var isNetworkEnable = false
    internal var latitude: Double = 0.toDouble()
    internal var longitude: Double = 0.toDouble()
    internal var locationManager: LocationManager? = null
    internal var location: Location? = null
    private val mHandler = Handler()
    private var mTimer: Timer? = null
    internal var notify_interval: Long = 10000000
    internal var intent: Intent? = null

    override fun onBind(intent: Intent): IBinder? {
        return null
    }

    override fun onCreate() {
        super.onCreate()

        mTimer = Timer()
        mTimer!!.schedule(TimerTaskToGetLocation(), 5, notify_interval)
        intent = Intent(str_receiver)
        //        fn_getlocation();
    }

    override fun onLocationChanged(location: Location) {

    }

    override fun onStatusChanged(provider: String, status: Int, extras: Bundle) {

    }

    override fun onProviderEnabled(provider: String) {

    }

    override fun onProviderDisabled(provider: String) {

    }

    @SuppressLint("MissingPermission")
    private fun fn_getlocation() {
        locationManager = applicationContext.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        isGPSEnable = locationManager!!.isProviderEnabled(LocationManager.GPS_PROVIDER)
        isNetworkEnable = locationManager!!.isProviderEnabled(LocationManager.NETWORK_PROVIDER)

        if (!isGPSEnable && !isNetworkEnable) {

        } else {

            if (isNetworkEnable) {
                location = null
                locationManager!!.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 100000000, 100000f, this)
                if (locationManager != null) {
                    location = locationManager!!.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                    if (location != null) {

                        Log.e("latitude", location!!.latitude.toString() + "")
                        Log.e("longitude", location!!.longitude.toString() + "")

                        latitude = location!!.latitude
                        longitude = location!!.longitude
                        fn_update(location!!)
                    }
                }

            }


            if (isGPSEnable) {
                location = null
                locationManager!!.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0f, this)
                if (locationManager != null) {
                    location = locationManager!!.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                    if (location != null) {
                        Log.e("latitude", location!!.latitude.toString() + "")
                        Log.e("longitude", location!!.longitude.toString() + "")
                        latitude = location!!.latitude
                        longitude = location!!.longitude
                        fn_update(location!!)
                    }
                }
            }


        }

    }

    private inner class TimerTaskToGetLocation : TimerTask() {
        override fun run() {

            mHandler.post { fn_getlocation() }

        }
    }

    private fun fn_update(location: Location) {

        intent?.putExtra("latutide", location.latitude.toString() + "")
        intent?.putExtra("longitude", location.longitude.toString() + "")
        sendBroadcast(intent)
    }

    companion object {
        var str_receiver = "servicetutorial.service.receiver"
    }


}
