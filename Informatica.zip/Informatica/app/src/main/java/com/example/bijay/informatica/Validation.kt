package com.example.bijay.informatica

import android.widget.EditText

/**
 * Created by Bijay on 9/29/2017.
 */

object Validation {

    fun hasTextFirstName(editText: EditText): Boolean {
        val REQUIRED_MSG = "First name can't be blank"
        val text = editText.text.toString().trim { it <= ' ' }
        editText.error = null

        // length 0 means there is no text
        if (text.length == 0) {
            editText.error = REQUIRED_MSG
            return false
        }

        return true
    }

    fun hasTextLastName(editText: EditText): Boolean {
        val REQUIRED_MSG = "Last name can't be blank"
        val text = editText.text.toString().trim { it <= ' ' }
        editText.error = null

        // length 0 means there is no text
        if (text.length == 0) {
            editText.error = REQUIRED_MSG
            return false
        }

        return true
    }
}
